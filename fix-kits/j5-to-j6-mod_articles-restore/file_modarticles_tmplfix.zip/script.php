<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Log\Log;

class FileModarticlesTmplfixInstallerScript
{
    public function postflight($type, $parent)
    {
        $rootBase = JPATH_ROOT . '/modules/mod_articles/tmpl/';
        $files = [
            'default.php'        => 1408,
            'default_items.php'  => 8237,
            'default_titles.php' => 1425,
        ];

        $report = [];
        foreach ($files as $name => $expectedMin) {
            $path = $rootBase . $name;
            $exists = file_exists($path);
            $size   = $exists ? filesize($path) : -1;
            $report[$name] = ['exists' => $exists, 'size' => $size, 'expected_size' => $expectedMin];

            if ($exists && function_exists('opcache_invalidate')) {
                opcache_invalidate($path, true);
            }
        }
        if (function_exists('opcache_reset')) {
            opcache_reset();
            $report['_opcache_reset'] = true;
        }

        $msg = "[file_modarticles_tmplfix postflight] " . json_encode($report);

        // Surface to Joomla log + UI message
        try { Log::add($msg, Log::INFO, 'com_installer'); } catch (\Throwable $e) {}
        try { Factory::getApplication()->enqueueMessage($msg, 'info'); } catch (\Throwable $e) {}

        // Also write to file so we can fetch via filesystem if needed
        @file_put_contents(JPATH_ROOT . '/tmp/file_modarticles_tmplfix_postflight.json', $msg);

        return true;
    }
}
